
#ifndef ANT_H
#define ANT_H

#include "Creature.h"

class Ant: public Creature{
private:
public:
	Ant();
	void dailyActions(Creature * c);
protected:
};

#endif
